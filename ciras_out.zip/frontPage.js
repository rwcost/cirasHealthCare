/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$(function() { // wait til the document is ready before we start trying to access its elements

    $('#submit').click(function(){
    alert("hello");
                    
                });    
                    
});                    
 