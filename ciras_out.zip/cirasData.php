
<?php

$string = file_get_contents("http://cirasheartcare.com/bob/cirasData.json");
echo $string;

?>